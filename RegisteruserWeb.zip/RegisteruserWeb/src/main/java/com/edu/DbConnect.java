package com.edu;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbConnect {
	//Connection with database
			static String driver = "com.mysql.cj.jdbc.Driver";
			static String url = "jdbc:mysql://localhost:3306/Servletdb";
			static String un = "root";
			static String upass = "root";
			static Connection con;
			
			public static Connection getConnection() {
			
			try {
				
				Class.forName(driver);
//				get connection
			    con = DriverManager.getConnection(url,un,upass);
				if(con==null) {
					System.out.println("Connection is null");
				}
				
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			return con;

}
}