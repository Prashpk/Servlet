package com.edu;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SimpleCalcServlet
 */
@WebServlet("/SimpleCalcServlet")
public class SimpleCalcServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SimpleCalcServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
       
		PrintWriter out = response.getWriter();
		
		int n1 = Integer.parseInt(request.getParameter("num1"));
		int n2 = Integer.parseInt(request.getParameter("num2"));
		int res;
		double ans;
		String bn = request.getParameter("op");
		
		switch(bn) {
		
		case "add" :
		    res = n1 + n2;
			out.println("addition of "+n1+ " and " +n2+" is "+res);
			break;
			
		case "sub" :
		    res = n1 - n2;
			out.println("subtaraction of "+n1+ " and " +n2+" is "+res);
			break;
			
		case "mul" :
		    res = n1 * n2;
			out.println("addition of "+n1+ " and " +n2+" is "+res);
			break;
			
		case "div" :
		
	    if(n2==0){
	    	out.println("divide by zero Error");
	    }
		else {
		    ans = n1 / n2;
			out.println("Quotient of "+n1+ " and " +n2+" is "+ans);
			break;
		}
		
		}
		}
		
	}

